package net.adminrunet.h9clusterdemo;

/** Source of complete dashboard snapshots. The renderer does not know where data comes from. */
public interface DashboardDataSource {
    interface Listener {
        void onDashboardState(DashboardState state);
    }

    void start(Listener listener);

    void stop();
}

