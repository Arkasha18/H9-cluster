package net.adminrunet.h9clusterdemo;

/** One immutable snapshot of every value and status rendered by the dashboard. */
public final class DashboardState {
    public final float speedKph;
    public final float rpm;
    public final float fuelLiters;
    public final float coolantC;
    public final float steeringAngleDeg;
    public final double odometerKm;
    public final float dayKm;
    public final float tripKm;
    public final int rangeKm;
    public final float outsideTemperatureC;
    public final float tyreFrontLeftBar;
    public final float tyreFrontRightBar;
    public final float tyreRearLeftBar;
    public final float tyreRearRightBar;
    public final float consumptionLitersPer100Km;
    public final float batteryVoltage;

    public DashboardState(
            float speedKph,
            float rpm,
            float fuelLiters,
            float coolantC,
            float steeringAngleDeg,
            double odometerKm,
            float dayKm,
            float tripKm,
            int rangeKm,
            float outsideTemperatureC,
            float tyreFrontLeftBar,
            float tyreFrontRightBar,
            float tyreRearLeftBar,
            float tyreRearRightBar,
            float consumptionLitersPer100Km,
            float batteryVoltage) {
        this.speedKph = speedKph;
        this.rpm = rpm;
        this.fuelLiters = fuelLiters;
        this.coolantC = coolantC;
        this.steeringAngleDeg = steeringAngleDeg;
        this.odometerKm = odometerKm;
        this.dayKm = dayKm;
        this.tripKm = tripKm;
        this.rangeKm = rangeKm;
        this.outsideTemperatureC = outsideTemperatureC;
        this.tyreFrontLeftBar = tyreFrontLeftBar;
        this.tyreFrontRightBar = tyreFrontRightBar;
        this.tyreRearLeftBar = tyreRearLeftBar;
        this.tyreRearRightBar = tyreRearRightBar;
        this.consumptionLitersPer100Km = consumptionLitersPer100Km;
        this.batteryVoltage = batteryVoltage;
    }

    public static DashboardState initial() {
        return new DashboardState(
                0.0f,
                700.0f,
                76.0f,
                48.0f,
                0.0f,
                6702.0,
                354.0f,
                338.0f,
                520,
                18.0f,
                2.30f,
                2.31f,
                2.29f,
                2.30f,
                11.1f,
                12.4f);
    }
}
