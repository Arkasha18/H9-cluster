package net.adminrunet.h9clusterdemo;

import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;

/**
 * Autonomous 36-second driving cycle. It deliberately changes every dynamic item so the
 * layout can be verified without a vehicle or any vendor service.
 */
public final class DemoDashboardDataSource implements DashboardDataSource {
    private static final long UPDATE_INTERVAL_MS = 100L;
    private static final float CYCLE_SECONDS = 36.0f;
    private static final float TWO_PI = (float) (Math.PI * 2.0);

    private final Handler handler = new Handler(Looper.getMainLooper());
    private Listener listener;
    private boolean running;
    private long startedAtMs;

    private final Runnable ticker = new Runnable() {
        @Override
        public void run() {
            if (!running) {
                return;
            }
            publish();
            handler.postDelayed(this, UPDATE_INTERVAL_MS);
        }
    };

    @Override
    public void start(Listener listener) {
        this.listener = listener;
        this.running = true;
        this.startedAtMs = SystemClock.elapsedRealtime();
        handler.removeCallbacks(ticker);
        handler.post(ticker);
    }

    @Override
    public void stop() {
        running = false;
        handler.removeCallbacks(ticker);
        listener = null;
    }

    private void publish() {
        Listener current = listener;
        if (current == null) {
            return;
        }

        float elapsedSeconds = (SystemClock.elapsedRealtime() - startedAtMs) / 1000.0f;
        float cycle = elapsedSeconds % CYCLE_SECONDS;
        float phase = cycle / CYCLE_SECONDS;

        String gear;
        float movingPhase = 0.0f;
        boolean moving = false;
        if (cycle < 1.5f) {
            gear = "P";
        } else if (cycle < 3.0f) {
            gear = "R";
        } else if (cycle < 4.5f) {
            gear = "N";
        } else if (cycle < 34.5f) {
            gear = "D";
            moving = true;
            movingPhase = (cycle - 4.5f) / 30.0f;
        } else {
            gear = "P";
        }

        float speed = moving
                ? 220.0f * smoothPulse(movingPhase)
                : 0.0f;

        float rpm;
        if (!moving) {
            rpm = gear.equals("R") ? 1150.0f : 700.0f;
        } else {
            float shiftWave = 0.5f + 0.5f
                    * (float) Math.sin((movingPhase * 12.0f - 0.35f) * TWO_PI);
            rpm = 900.0f + speed * 19.5f + 850.0f * shiftWave;
            rpm = clamp(rpm, 850.0f, 5950.0f);
        }

        float fuel = 76.0f - 67.0f * smoothPulse(phase);
        float coolant = 48.0f
                + 48.0f * smoothPulse(phase)
                + 2.5f * (float) Math.sin(phase * TWO_PI * 3.0f)
                * smoothPulse(phase);
        float steering = 430.0f * (float) Math.sin(phase * TWO_PI * 2.0f);
        float outside = 18.0f + 3.0f * (float) Math.sin(phase * TWO_PI);

        float fl = 2.30f + 0.07f * (float) Math.sin(phase * TWO_PI);
        float fr = 2.32f + 0.06f * (float) Math.sin(phase * TWO_PI + 0.7f);
        float rl = 2.28f + 0.05f * (float) Math.sin(phase * TWO_PI + 1.4f);
        float rr = 2.31f + 0.06f * (float) Math.sin(phase * TWO_PI + 2.1f);

        float consumption = 8.7f + 3.4f * (float) Math.sin(phase * TWO_PI * 2.0f);
        float voltage = moving
                ? 13.8f + 0.18f * (float) Math.sin(phase * TWO_PI * 3.0f)
                : 12.4f + 0.08f * (float) Math.sin(phase * TWO_PI);

        double travelled = elapsedSeconds * 0.0025;
        int range = Math.round(70.0f + fuel * 6.1f);
        current.onDashboardState(new DashboardState(
                speed,
                rpm,
                fuel,
                coolant,
                steering,
                6702.0 + travelled,
                354.0f + (float) travelled,
                338.0f + (float) travelled,
                range,
                outside,
                fl,
                fr,
                rl,
                rr,
                consumption,
                voltage));
    }

    private static float smoothPulse(float phase) {
        float clamped = clamp(phase, 0.0f, 1.0f);
        return 0.5f - 0.5f * (float) Math.cos(clamped * TWO_PI);
    }

    private static float clamp(float value, float min, float max) {
        return Math.max(min, Math.min(max, value));
    }
}
