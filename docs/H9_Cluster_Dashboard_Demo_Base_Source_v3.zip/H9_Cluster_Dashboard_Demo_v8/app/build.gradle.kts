plugins {
    id("com.android.application")
}

android {
    namespace = "net.adminrunet.h9clusterdemo"
    compileSdk = 35

    defaultConfig {
        applicationId = "net.adminrunet.h9clusterdemo"
        minSdk = 28
        targetSdk = 28
        versionCode = 2026072415
        versionName = "8.0.7-background-and-geometry-calibration"
    }

    buildTypes {
        debug {
            isMinifyEnabled = false
        }
        release {
            isMinifyEnabled = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_1_8
        targetCompatibility = JavaVersion.VERSION_1_8
    }

    lint {
        // This APK is installed directly on the Android 9 vehicle cluster and is
        // intentionally not a Google Play target.
        disable += "ExpiredTargetSdkVersion"
    }
}
