#!/usr/bin/env python3
"""Validate DEX identifier ordering required by the Android runtime."""

from __future__ import annotations

import argparse
import hashlib
import struct
import sys
import zipfile
import zlib
from pathlib import Path


def u16(data: bytes, offset: int) -> int:
    return struct.unpack_from("<H", data, offset)[0]


def u32(data: bytes, offset: int) -> int:
    return struct.unpack_from("<I", data, offset)[0]


def read_dex(path: Path) -> bytes:
    if path.suffix.lower() == ".apk":
        with zipfile.ZipFile(path) as archive:
            return archive.read("classes.dex")
    return path.read_bytes()


def type_list(data: bytes, offset: int) -> tuple[int, ...]:
    if offset == 0:
        return ()
    size = u32(data, offset)
    return tuple(u16(data, offset + 4 + index * 2) for index in range(size))


def strictly_sorted(values: list[tuple[int, ...]], section: str) -> None:
    for index in range(1, len(values)):
        if values[index - 1] >= values[index]:
            raise ValueError(
                f"{section} is out of order at indexes {index - 1} and {index}: "
                f"{values[index - 1]} >= {values[index]}"
            )


def validate(data: bytes) -> None:
    if data[:8] not in (b"dex\n035\0", b"dex\n037\0", b"dex\n038\0", b"dex\n039\0"):
        raise ValueError(f"unsupported DEX magic: {data[:8]!r}")
    if u32(data, 0x20) != len(data):
        raise ValueError("DEX file_size does not match the payload length")
    if hashlib.sha1(data[32:]).digest() != data[12:32]:
        raise ValueError("DEX SHA-1 signature is invalid")
    if zlib.adler32(data[12:]) & 0xFFFFFFFF != u32(data, 8):
        raise ValueError("DEX Adler-32 checksum is invalid")

    type_size, type_offset = u32(data, 0x40), u32(data, 0x44)
    type_ids = [(u32(data, type_offset + index * 4),) for index in range(type_size)]
    strictly_sorted(type_ids, "type_ids")

    proto_size, proto_offset = u32(data, 0x48), u32(data, 0x4C)
    proto_ids = []
    for index in range(proto_size):
        item = proto_offset + index * 12
        return_type = u32(data, item + 4)
        parameters = type_list(data, u32(data, item + 8))
        proto_ids.append((return_type, *parameters))
    strictly_sorted(proto_ids, "proto_ids")

    field_size, field_offset = u32(data, 0x50), u32(data, 0x54)
    field_ids = [
        (
            u16(data, field_offset + index * 8),
            u32(data, field_offset + index * 8 + 4),
            u16(data, field_offset + index * 8 + 2),
        )
        for index in range(field_size)
    ]
    strictly_sorted(field_ids, "field_ids")

    method_size, method_offset = u32(data, 0x58), u32(data, 0x5C)
    method_ids = [
        (
            u16(data, method_offset + index * 8),
            u32(data, method_offset + index * 8 + 4),
            u16(data, method_offset + index * 8 + 2),
        )
        for index in range(method_size)
    ]
    strictly_sorted(method_ids, "method_ids")

    class_size, class_offset = u32(data, 0x60), u32(data, 0x64)
    class_defs = [
        (u32(data, class_offset + index * 32),) for index in range(class_size)
    ]
    strictly_sorted(class_defs, "class_defs")


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("path", type=Path)
    arguments = parser.parse_args()
    try:
        validate(read_dex(arguments.path))
    except (KeyError, OSError, ValueError, zipfile.BadZipFile) as error:
        print(f"INVALID: {error}", file=sys.stderr)
        return 1
    print("OK: DEX checksums and identifier ordering are valid")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
