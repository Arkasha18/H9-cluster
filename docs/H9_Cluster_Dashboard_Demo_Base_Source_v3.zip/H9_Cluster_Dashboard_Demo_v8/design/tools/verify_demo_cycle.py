#!/usr/bin/env python3
"""Verify the 36-second simulated cycle and all four calibrated gauge paths."""

from math import cos, pi, sin, sqrt


def clamp(value, low, high):
    return max(low, min(high, value))


def pulse(phase):
    return 0.5 - 0.5 * cos(clamp(phase, 0.0, 1.0) * 2.0 * pi)


rows = []
gears = set()
for index in range(361):
    elapsed = index / 10.0
    cycle = elapsed % 36.0
    phase = cycle / 36.0
    moving = 4.5 <= cycle < 34.5
    moving_phase = (cycle - 4.5) / 30.0 if moving else 0.0

    if cycle < 1.5:
        gear = "P"
    elif cycle < 3.0:
        gear = "R"
    elif cycle < 4.5:
        gear = "N"
    elif cycle < 34.5:
        gear = "D"
    else:
        gear = "P"
    gears.add(gear)

    speed = 220.0 * pulse(moving_phase) if moving else 0.0
    if not moving:
        rpm = 1150.0 if gear == "R" else 700.0
    else:
        shift_wave = 0.5 + 0.5 * sin(
            (moving_phase * 12.0 - 0.35) * 2.0 * pi
        )
        rpm = clamp(900.0 + speed * 19.5 + 850.0 * shift_wave, 850.0, 5950.0)

    fuel = 76.0 - 67.0 * pulse(phase)
    coolant = (
        48.0
        + 48.0 * pulse(phase)
        + 2.5 * sin(phase * 2.0 * pi * 3.0) * pulse(phase)
    )
    steering = 430.0 * sin(phase * 2.0 * pi * 2.0)
    outside = 18.0 + 3.0 * sin(phase * 2.0 * pi)
    consumption = 8.7 + 3.4 * sin(phase * 2.0 * pi * 2.0)
    rows.append((speed, rpm, fuel, coolant, steering, outside, consumption))


def column(index):
    return [row[index] for row in rows]


assert min(column(0)) == 0.0
assert max(column(0)) > 219.9
assert 690.0 <= min(column(1)) <= 710.0
assert 5500.0 < max(column(1)) <= 5950.0
assert min(column(2)) < 9.1 and max(column(2)) == 76.0
assert min(column(3)) >= 48.0 and max(column(3)) > 94.0
assert min(column(4)) < -429.0 and max(column(4)) > 429.0
assert min(column(5)) < 15.1 and max(column(5)) > 20.9
assert min(column(6)) < 5.4 and max(column(6)) > 12.0
assert gears == {"P", "R", "N", "D"}

for item in range(7):
    assert abs(rows[0][item] - rows[-1][item]) < 0.0001


def ellipse_radius(rx, ry, angle_degrees):
    angle = angle_degrees * pi / 180.0
    cosine = cos(angle)
    sine = sin(angle)
    return rx * ry / sqrt(
        ry * ry * cosine * cosine + rx * rx * sine * sine
    )


def needle_segment(cx, cy, rx, ry, angle_degrees, gap, length):
    angle = angle_degrees * pi / 180.0
    cosine = cos(angle)
    sine = sin(angle)
    scale_radius = ellipse_radius(rx, ry, angle_degrees)
    base_radius = max(length + 8.0, scale_radius - gap)
    base = (cx + cosine * base_radius, cy + sine * base_radius)
    tip = (
        base[0] - cosine * length,
        base[1] - sine * length,
    )
    return base, tip, scale_radius - base_radius


def segment_misses_rect(segment, rect):
    (base_x, base_y), (tip_x, tip_y), _ = segment
    left, top, right, bottom = rect
    for index in range(65):
        fraction = index / 64.0
        x = base_x + (tip_x - base_x) * fraction
        y = base_y + (tip_y - base_y) * fraction
        if left <= x <= right and top <= y <= bottom:
            return False
    return True


speed_safe = (265.0, 350.0, 433.0, 480.0)
rpm_safe = (1492.0, 350.0, 1670.0, 480.0)
fuel_safe = [
    (560.0, 243.0, 632.0, 317.0),
    (541.0, 352.0, 575.0, 388.0),
]
coolant_safe = (1280.0, 245.0, 1320.0, 294.0)

for index in range(1001):
    fraction = index / 1000.0
    speed_segment = needle_segment(
        342.0, 410.0, 260.0, 246.0,
        90.0 + 220.0 * fraction, 72.0, 56.0,
    )
    rpm_segment = needle_segment(
        1578.0, 410.0, 260.0, 246.0,
        90.0 - 220.0 * fraction, 72.0, 56.0,
    )
    assert abs(speed_segment[0][0] + rpm_segment[0][0] - 1920.0) < 0.001
    assert abs(speed_segment[0][1] - rpm_segment[0][1]) < 0.001
    assert abs(speed_segment[2] - 72.0) < 0.001
    assert abs(rpm_segment[2] - 72.0) < 0.001
    assert segment_misses_rect(speed_segment, speed_safe)
    assert segment_misses_rect(rpm_segment, rpm_safe)

    fuel_segment = needle_segment(
        620.0, 305.0, 90.0, 120.0,
        120.0 - 196.0 * fraction, 22.0, 42.0,
    )
    coolant_segment = needle_segment(
        1300.0, 305.0, 90.0, 120.0,
        64.0 + 173.0 * fraction, 22.0, 42.0,
    )
    assert abs(fuel_segment[2] - 22.0) < 0.001
    assert abs(coolant_segment[2] - 22.0) < 0.001
    assert all(segment_misses_rect(fuel_segment, rect) for rect in fuel_safe)
    assert segment_misses_rect(coolant_segment, coolant_safe)

assert (1335.0 + 1459.0) * 0.5 == 1397.0
assert (529.0 + 559.0) * 0.5 == 544.0


print("Cycle samples: 361 at 100 ms")
print(f"Speed: {min(column(0)):.0f}..{max(column(0)):.0f} km/h")
print(f"RPM: {min(column(1)):.0f}..{max(column(1)):.0f}")
print(f"Fuel: {min(column(2)):.1f}..{max(column(2)):.1f} L")
print(f"Coolant: {min(column(3)):.1f}..{max(column(3)):.1f} C")
print(f"Steering: {min(column(4)):.0f}..{max(column(4)):.0f} deg")
print(f"Outside: {min(column(5)):.1f}..{max(column(5)):.1f} C")
print(f"Consumption: {min(column(6)):.1f}..{max(column(6)):.1f} L/100km")
print(f"Gears generated but not rendered: {','.join(sorted(gears))}")
print("Cycle boundary continuity: OK")
print("Four calibrated gauge paths: OK")
print("Mirrored gauge geometry: OK")
print("Constant main-scale gap: 72 px")
print("Constant small-scale gap: 22 px")
print("Dynamic text safe zones: OK")
print("Tyre-pressure symmetry around car center: OK")
