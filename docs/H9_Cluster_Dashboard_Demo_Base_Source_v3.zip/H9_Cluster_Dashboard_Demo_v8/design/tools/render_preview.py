#!/usr/bin/env python3
"""Render a representative 1920x720 frame from the v8.0.7 geometry."""

from math import atan2, cos, pi, radians, sin, sqrt
from pathlib import Path

from PIL import Image, ImageDraw, ImageFont


PROJECT = Path(__file__).resolve().parents[2]
ASSETS = PROJECT / "app/src/main/assets"
OUTPUT = PROJECT / "release/H9_Cluster_Dashboard_Demo_v8_Preview.png"
SIZE = (1920, 720)


def font(relative_path: str, size: int) -> ImageFont.FreeTypeFont:
    return ImageFont.truetype(str(ASSETS / relative_path), size=size)


def draw_fitted_text(
    image: Image.Image,
    value: str,
    center: tuple[float, float],
    maximum_width: float,
    desired_size: int,
    minimum_size: int,
    fill: tuple[int, int, int, int],
    font_path: str = "fonts/Rajdhani-Medium.ttf",
) -> None:
    draw = ImageDraw.Draw(image)
    size = desired_size
    selected = font(font_path, size)
    while size > minimum_size:
        bounds = draw.textbbox((0, 0), value, font=selected)
        if bounds[2] - bounds[0] <= maximum_width:
            break
        size -= 1
        selected = font(font_path, size)
    draw.text(center, value, font=selected, fill=fill, anchor="mm")


def draw_scale_needle(
    image: Image.Image,
    needle: Image.Image,
    center: tuple[float, float],
    radii: tuple[float, float],
    angle_degrees: float,
    gap: float,
    length: float,
    thickness: float,
) -> None:
    angle = radians(angle_degrees)
    cosine = cos(angle)
    sine = sin(angle)
    radius_x, radius_y = radii
    scale_radius = radius_x * radius_y / sqrt(
        radius_y * radius_y * cosine * cosine
        + radius_x * radius_x * sine * sine
    )
    base_radius = max(length + 8.0, scale_radius - gap)
    base_x = center[0] + cosine * base_radius
    base_y = center[1] + sine * base_radius
    inward = atan2(center[1] - base_y, center[0] - base_x) * 180.0 / pi
    rotation = inward - 180.0

    resized = needle.resize(
        (round(length), round(thickness)),
        Image.Resampling.LANCZOS,
    )
    tile_radius = round(length + 14.0)
    tile = Image.new(
        "RGBA",
        (tile_radius * 2, tile_radius * 2),
        (0, 0, 0, 0),
    )
    tile.alpha_composite(
        resized,
        (tile_radius - round(length), tile_radius - round(thickness * 0.5)),
    )
    tile = tile.rotate(
        -rotation,
        resample=Image.Resampling.BICUBIC,
        center=(tile_radius, tile_radius),
    )
    image.alpha_composite(
        tile,
        (round(base_x - tile_radius), round(base_y - tile_radius)),
    )


def draw_steering_wheel(
    draw: ImageDraw.ImageDraw,
    center_x: float,
    center_y: float,
    radius: float,
    fill: tuple[int, int, int, int],
) -> None:
    width = 2
    draw.ellipse(
        (
            center_x - radius,
            center_y - radius,
            center_x + radius,
            center_y + radius,
        ),
        outline=fill,
        width=width,
    )
    draw.ellipse(
        (center_x - 3, center_y - 3, center_x + 3, center_y + 3),
        outline=fill,
        width=width,
    )
    draw.line(
        (center_x, center_y - 3, center_x, center_y - radius),
        fill=fill,
        width=width,
    )
    draw.line(
        (
            center_x - 2.5,
            center_y + 2,
            center_x - radius * 0.78,
            center_y + radius * 0.55,
        ),
        fill=fill,
        width=width,
    )
    draw.line(
        (
            center_x + 2.5,
            center_y + 2,
            center_x + radius * 0.78,
            center_y + radius * 0.55,
        ),
        fill=fill,
        width=width,
    )


def main() -> None:
    frame = Image.open(
        ASSETS / "dashboard/background_classic.png"
    ).convert("RGBA")
    if frame.size != SIZE:
        raise RuntimeError(f"Unexpected background size: {frame.size}")

    draw = ImageDraw.Draw(frame)
    for box in ((522, 12, 682, 76), (706, 12, 882, 76), (1038, 12, 1214, 76)):
        draw.rounded_rectangle(
            box,
            radius=19,
            fill=(8, 11, 14, 232),
            outline=(76, 83, 90, 255),
            width=2,
        )
    draw.text(
        (602, 45),
        "13:27",
        font=font("fonts/Inter-Regular.ttf", 31),
        fill=(255, 255, 255, 255),
        anchor="mm",
    )

    yellow = Image.open(
        ASSETS / "dashboard/panel_needle_main_trimmed.png"
    ).convert("RGBA")
    white = Image.open(
        ASSETS / "dashboard/panel_needle_small_trimmed.png"
    ).convert("RGBA")

    speed = 138.0
    rpm = 4250.0
    fuel = 37.0
    coolant = 91.0
    draw_scale_needle(
        frame,
        yellow,
        (342.0, 410.0),
        (260.0, 246.0),
        90.0 + speed,
        72.0,
        56.0,
        12.0,
    )
    draw_scale_needle(
        frame,
        yellow,
        (1578.0, 410.0),
        (260.0, 246.0),
        90.0 - rpm / 8000.0 * 220.0,
        72.0,
        56.0,
        12.0,
    )
    draw_scale_needle(
        frame,
        white,
        (620.0, 305.0),
        (90.0, 120.0),
        120.0 - fuel / 80.0 * 196.0,
        22.0,
        42.0,
        10.0,
    )
    draw_scale_needle(
        frame,
        white,
        (1300.0, 305.0),
        (90.0, 120.0),
        64.0 + (coolant - 40.0) / 90.0 * 173.0,
        22.0,
        42.0,
        10.0,
    )

    white_text = (247, 247, 245, 255)
    draw_fitted_text(frame, "138", (349, 420), 168, 112, 92, white_text)
    draw_fitted_text(frame, "4.2", (1581, 420), 178, 112, 92, white_text)
    draw = ImageDraw.Draw(frame)
    draw.text(
        (349, 485),
        "km/h",
        font=font("fonts/Inter-Regular.ttf", 20),
        fill=(200, 205, 209, 255),
        anchor="mm",
    )

    draw_fitted_text(frame, "296 km", (596, 260), 72, 29, 22, (231, 232, 232, 255))
    draw_fitted_text(frame, "37 L", (596, 298), 72, 29, 22, (231, 232, 232, 255))
    draw_fitted_text(frame, "0.5", (558, 370), 34, 27, 20, (207, 210, 212, 255))
    draw_fitted_text(frame, "91", (1300, 270), 40, 31, 23, (244, 244, 242, 255))

    draw = ImageDraw.Draw(frame)
    label_font = font("fonts/Inter-Regular.ttf", 20)
    value_font = font("fonts/Rajdhani-Medium.ttf", 23)
    for label, value, baseline in (
        ("ODO:", "6702  km", 555),
        ("Day:", "354.1  km", 591),
        ("Trip:", "338.1  km", 627),
    ):
        draw.text(
            (407, baseline),
            label,
            font=label_font,
            fill=(240, 240, 238, 255),
            anchor="ls",
        )
        draw.text(
            (485, baseline),
            value,
            font=value_font,
            fill=(248, 248, 247, 255),
            anchor="ls",
        )

    for value, center in (
        ("2.34", (1335, 529)),
        ("2.36", (1459, 529)),
        ("2.31", (1335, 559)),
        ("2.33", (1459, 559)),
    ):
        draw_fitted_text(frame, value, center, 74, 24, 19, (244, 244, 242, 255))

    draw = ImageDraw.Draw(frame)
    draw_steering_wheel(draw, 762, 44, 13, (217, 222, 226, 255))
    draw.text(
        (784, 53),
        "+126°",
        font=font("fonts/Inter-Regular.ttf", 23),
        fill=(247, 247, 245, 255),
        anchor="ls",
    )
    draw.text(
        (1126, 45),
        "19.6 °C",
        font=font("fonts/Inter-Regular.ttf", 27),
        fill=(249, 249, 247, 255),
        anchor="mm",
    )

    draw_fitted_text(frame, "10.8L", (91, 678), 112, 32, 24, (245, 245, 243, 255))
    draw = ImageDraw.Draw(frame)
    draw.text(
        (46, 712),
        "/100 km",
        font=font("fonts/Inter-Regular.ttf", 16),
        fill=(214, 217, 219, 255),
        anchor="ls",
    )
    draw_fitted_text(frame, "13.9V", (1830, 678), 112, 32, 24, (245, 245, 243, 255))

    OUTPUT.parent.mkdir(parents=True, exist_ok=True)
    frame.save(OUTPUT, optimize=True)
    print(OUTPUT)


if __name__ == "__main__":
    main()
