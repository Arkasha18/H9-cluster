"""Rebuild the Android PNG assets from the original 2048x768 design sources."""

from pathlib import Path

import numpy as np
from PIL import Image, ImageDraw, ImageFilter


PROJECT = Path(__file__).resolve().parents[2]
REFERENCE = PROJECT / "design/reference"
ASSETS = PROJECT / "app/src/main/assets/dashboard"
CANVAS_SIZE = (1920, 720)
GAUGE_SHRINK_PX = 34.0
SUPERSAMPLE = 4


def expand_mask(mask: np.ndarray, iterations: int) -> np.ndarray:
    expanded = mask.copy()
    for _ in range(iterations):
        source = expanded.copy()
        for dy in (-1, 0, 1):
            for dx in (-1, 0, 1):
                if dx == 0 and dy == 0:
                    continue
                expanded |= np.roll(np.roll(source, dy, axis=0), dx, axis=1)
    return expanded


def inpaint_thin_symbols(pixels: np.ndarray, mask: np.ndarray) -> np.ndarray:
    result = pixels.astype(np.float32)
    known = ~mask
    remaining = mask.copy()

    for _ in range(80):
        if not remaining.any():
            break
        total = np.zeros_like(result)
        count = np.zeros(mask.shape, dtype=np.float32)
        for dy in (-1, 0, 1):
            for dx in (-1, 0, 1):
                if dx == 0 and dy == 0:
                    continue
                shifted_known = np.roll(np.roll(known, dy, axis=0), dx, axis=1)
                shifted_pixels = np.roll(np.roll(result, dy, axis=0), dx, axis=1)
                total += shifted_pixels * shifted_known[:, :, None]
                count += shifted_known
        fillable = remaining & (count > 0.0)
        result[fillable] = total[fillable] / count[fillable, None]
        known[fillable] = True
        remaining[fillable] = False

    return np.clip(result, 0.0, 255.0).astype(np.uint8)


def remove_baked_dynamic_icons(image: Image.Image) -> Image.Image:
    rgba = np.array(image.convert("RGBA"))
    rgb = rgba[:, :, :3]
    red = rgb[:, :, 0]
    green = rgb[:, :, 1]
    blue = rgb[:, :, 2]
    mask = np.zeros(red.shape, dtype=bool)

    fuel_region = np.zeros_like(mask)
    fuel_region[322:369, 546:600] = True
    mask |= fuel_region

    coolant_region = np.zeros_like(mask)
    coolant_region[294:374, 1287:1348] = True
    mask |= coolant_region

    limit_region = np.zeros_like(mask)
    limit_region[173:220, 1225:1294] = True
    limit_region[391:442, 1312:1380] = True
    limit_region[174:216, 610:650] = True
    limit_region[394:438, 540:582] = True
    channel_max = rgb.max(axis=2)
    channel_min = rgb.min(axis=2)
    grey_glyph = (channel_max > 25) & ((channel_max - channel_min) < 22)
    mask |= expand_mask(limit_region & grey_glyph, 1)

    malformed_red_region = np.zeros_like(mask)
    malformed_red_region[165:245, 1180:1278] = True
    malformed_red = (
        (red > 45)
        & (red > green * 1.45)
        & (red > blue * 1.45)
    )
    mask |= expand_mask(malformed_red_region & malformed_red, 3)

    cleaned = rgba.copy()
    cleaned[:, :, :3] = inpaint_thin_symbols(rgb, mask)
    return Image.fromarray(cleaned, mode="RGBA")


def prepare_needle(source_name: str, output_name: str) -> None:
    needle = Image.open(REFERENCE / source_name).convert("RGBA")
    bounds = needle.getchannel("A").getbbox()
    if bounds is None:
        raise RuntimeError(f"No visible pixels in {source_name}")
    needle = needle.crop(bounds)
    padded = Image.new("RGBA", (needle.width + 8, needle.height + 8), (0, 0, 0, 0))
    padded.alpha_composite(needle, (4, 4))
    padded.save(ASSETS / output_name)


def feathered_polygon_mask(
    size: tuple[int, int],
    points: list[tuple[float, float]],
    blur_radius: float = 2.0,
) -> Image.Image:
    scale = SUPERSAMPLE
    mask = Image.new("L", (size[0] * scale, size[1] * scale), 0)
    draw = ImageDraw.Draw(mask)
    draw.polygon(
        [(round(x * scale), round(y * scale)) for x, y in points],
        fill=255,
    )
    mask = mask.resize(size, Image.Resampling.LANCZOS)
    if blur_radius > 0.0:
        mask = mask.filter(ImageFilter.GaussianBlur(blur_radius))
    return mask


def ellipse_mask(
    size: tuple[int, int],
    center: tuple[float, float],
    radii: tuple[float, float],
    blur_radius: float = 2.0,
) -> Image.Image:
    scale = SUPERSAMPLE
    mask = Image.new("L", (size[0] * scale, size[1] * scale), 0)
    draw = ImageDraw.Draw(mask)
    cx, cy = center
    rx, ry = radii
    draw.ellipse(
        (
            round((cx - rx) * scale),
            round((cy - ry) * scale),
            round((cx + rx) * scale),
            round((cy + ry) * scale),
        ),
        fill=255,
    )
    mask = mask.resize(size, Image.Resampling.LANCZOS)
    if blur_radius > 0.0:
        mask = mask.filter(ImageFilter.GaussianBlur(blur_radius))
    return mask


def shrink_large_gauge(
    image: Image.Image,
    center: tuple[float, float],
    outer_radii: tuple[float, float],
    preserve_polygon: list[tuple[float, float]],
) -> Image.Image:
    """Shrink only the large round dial while preserving its adjacent small gauge."""

    size = image.size
    cx, cy = center
    rx, ry = outer_radii
    # The luminous main scale has a 250-pixel reference radius. A 34-pixel
    # reduction therefore scales the complete dial artwork by this factor.
    scale = (250.0 - GAUGE_SHRINK_PX) / 250.0

    original_mask = ellipse_mask(size, center, outer_radii)
    preserve_mask = feathered_polygon_mask(size, preserve_polygon, 2.0)
    editable_mask = Image.fromarray(
        np.minimum(
            np.asarray(original_mask, dtype=np.uint8),
            255 - np.asarray(preserve_mask, dtype=np.uint8),
        ),
        mode="L",
    )

    # Remove the former rim, ticks and labels. The surrounding panel is intentionally
    # opaque black here, so this also hides the old dial cleanly without exposing the
    # stock launcher through the vacated 34-pixel band.
    dark_panel = Image.new("RGBA", size, (3, 5, 7, 255))
    result = Image.composite(dark_panel, image, editable_mask)

    left = max(0, int(np.floor(cx - rx - 4.0)))
    top = max(0, int(np.floor(cy - ry - 4.0)))
    right = min(size[0], int(np.ceil(cx + rx + 4.0)))
    bottom = min(size[1], int(np.ceil(cy + ry + 4.0)))
    crop = image.crop((left, top, right, bottom))
    crop_mask = editable_mask.crop((left, top, right, bottom))

    scaled_size = (
        max(1, round(crop.width * scale)),
        max(1, round(crop.height * scale)),
    )
    crop = crop.resize(scaled_size, Image.Resampling.LANCZOS)
    crop_mask = crop_mask.resize(scaled_size, Image.Resampling.LANCZOS)

    paste_x = round(cx - scaled_size[0] * 0.5)
    paste_y = round(cy - scaled_size[1] * 0.5)
    scaled_layer = Image.new("RGBA", size, (0, 0, 0, 0))
    scaled_layer.paste(crop, (paste_x, paste_y), crop_mask)

    # Never let the scaled large dial cover the original fuel/temperature insert.
    visible_scaled_mask = Image.fromarray(
        np.minimum(
            np.asarray(scaled_layer.getchannel("A"), dtype=np.uint8),
            255 - np.asarray(preserve_mask, dtype=np.uint8),
        ),
        mode="L",
    )
    scaled_layer.putalpha(visible_scaled_mask)
    result.alpha_composite(scaled_layer)
    return result


def color_mix(
    start: tuple[int, int, int],
    end: tuple[int, int, int],
    amount: float,
) -> tuple[int, int, int]:
    amount = max(0.0, min(1.0, amount))
    amount = amount * amount * (3.0 - 2.0 * amount)
    return tuple(
        round(start[index] + (end[index] - start[index]) * amount)
        for index in range(3)
    )


def ellipse_arc_points(
    center: tuple[float, float],
    radii: tuple[float, float],
    start_degrees: float,
    end_degrees: float,
    steps: int,
) -> list[tuple[float, float]]:
    cx, cy = center
    rx, ry = radii
    angles = np.linspace(start_degrees, end_degrees, steps + 1)
    radians = np.radians(angles)
    return list(zip(cx + rx * np.cos(radians), cy + ry * np.sin(radians)))


def draw_gradient_scale(
    image: Image.Image,
    center: tuple[float, float],
    radii: tuple[float, float],
    start_degrees: float,
    end_degrees: float,
    start_color: tuple[int, int, int],
    end_color: tuple[int, int, int],
) -> None:
    """Replace a segmented scale with one clean, anti-aliased color transition."""

    scale = SUPERSAMPLE
    hi_size = (image.width * scale, image.height * scale)
    points = ellipse_arc_points(
        center,
        radii,
        start_degrees,
        end_degrees,
        480,
    )

    cleanup = Image.new("RGBA", hi_size, (0, 0, 0, 0))
    cleanup_draw = ImageDraw.Draw(cleanup)
    cleanup_draw.line(
        [(round(x * scale), round(y * scale)) for x, y in points],
        fill=(3, 5, 7, 255),
        width=round(38 * scale),
        joint="curve",
    )
    cleanup = cleanup.resize(image.size, Image.Resampling.LANCZOS)
    image.alpha_composite(cleanup)

    glow = Image.new("RGBA", hi_size, (0, 0, 0, 0))
    glow_draw = ImageDraw.Draw(glow)
    line = Image.new("RGBA", hi_size, (0, 0, 0, 0))
    line_draw = ImageDraw.Draw(line)
    for index, point in enumerate(points):
        fraction = index / max(1, len(points) - 1)
        red, green, blue = color_mix(start_color, end_color, fraction)
        x = round(point[0] * scale)
        y = round(point[1] * scale)
        glow_radius = round(10 * scale)
        line_radius = round(5.5 * scale)
        glow_draw.ellipse(
            (
                x - glow_radius,
                y - glow_radius,
                x + glow_radius,
                y + glow_radius,
            ),
            fill=(red, green, blue, 105),
        )
        line_draw.ellipse(
            (
                x - line_radius,
                y - line_radius,
                x + line_radius,
                y + line_radius,
            ),
            fill=(red, green, blue, 255),
        )

    glow = glow.filter(ImageFilter.GaussianBlur(4.0 * scale))
    glow = glow.resize(image.size, Image.Resampling.LANCZOS)
    line = line.resize(image.size, Image.Resampling.LANCZOS)
    image.alpha_composite(glow)
    image.alpha_composite(line)


def refine_dashboard(image: Image.Image) -> Image.Image:
    image = shrink_large_gauge(
        image,
        center=(342.0, 410.0),
        outer_radii=(325.0, 285.0),
        preserve_polygon=[
            (575.0, 135.0),
            (780.0, 135.0),
            (780.0, 490.0),
            (480.0, 490.0),
        ],
    )
    image = shrink_large_gauge(
        image,
        center=(1578.0, 410.0),
        outer_radii=(325.0, 285.0),
        preserve_polygon=[
            (1140.0, 135.0),
            (1345.0, 135.0),
            (1440.0, 490.0),
            (1140.0, 490.0),
        ],
    )

    # Fuel: grey at E, smoothly warming to yellow at F.
    draw_gradient_scale(
        image,
        center=(620.0, 305.0),
        radii=(90.0, 120.0),
        start_degrees=120.0,
        end_degrees=-76.0,
        start_color=(166, 171, 174),
        end_color=(255, 205, 40),
    )
    # Coolant: grey at 40, smoothly warming to red at 130.
    draw_gradient_scale(
        image,
        center=(1300.0, 305.0),
        radii=(90.0, 120.0),
        start_degrees=64.0,
        end_degrees=237.0,
        start_color=(174, 179, 182),
        end_color=(255, 42, 35),
    )
    return image


def main() -> None:
    ASSETS.mkdir(parents=True, exist_ok=True)
    source = Image.open(REFERENCE / "background_classic_v807.png").convert("RGBA")
    if source.size != CANVAS_SIZE:
        raise RuntimeError(
            f"Expected {CANVAS_SIZE[0]}x{CANVAS_SIZE[1]}, got "
            f"{source.width}x{source.height}"
        )
    alpha = np.asarray(source.getchannel("A"), dtype=np.uint8)
    if alpha.min() != 0 or alpha.max() != 255:
        raise RuntimeError("The approved background must contain transparent and opaque pixels")
    source.save(ASSETS / "background_classic.png")
    prepare_needle("panel_needle_main_source.png", "panel_needle_main_trimmed.png")
    prepare_needle("panel_needle_small_source.png", "panel_needle_small_trimmed.png")


if __name__ == "__main__":
    main()
